import * as PIXI from 'pixi.js';
import { ThemeMode, GridMode } from './types';
import { PhiNodeBase } from '../PhiNodeBase/PhiNodeBase';
import {PhiNodeSettingsPanel} from '@/components/ComPhiStructure/subcomponents/PhiNodeBase/subcomponents/PhiNodeSettings/PhiNodeSettingsPanel'
import type { NodeSettingsData } from '@/components/ComPhiStructure/subcomponents/PhiNodeBase/subcomponents/PhiNodeSettings/types/types';

export class PhiConstructSpaceView {
    public app: PIXI.Application;
    private workspaceContainer: PIXI.Container;
    private uiContainer: PIXI.Container;
    private currentTheme: ThemeMode = 'dark';
    private currentGridMode: GridMode = 'lines';
    private nodeBase!: PhiNodeBase;
    private initializationPromise: Promise<void>;
    private isInitialized = false;
    // Редактирование названия
    private editInput: HTMLInputElement | null = null;
    private editOverlay: PIXI.Graphics | null = null;
    private blurFilter: PIXI.BlurFilter | null = null;
    private originalFilters: readonly PIXI.Filter[] = [];
    private settingsPanel: PhiNodeSettingsPanel | null = null;

    // Перетаскивание
    // private isDragging: boolean = false;
    // private activeNode: PhiNodeBase | null = null;

    constructor() {
        this.app = new PIXI.Application();
        this.workspaceContainer = new PIXI.Container();
        this.uiContainer = new PIXI.Container();
        this.initializationPromise = this.initializeApp();
    }

    public async waitForInitialization(): Promise<void> {
        return this.initializationPromise;
    }

    // Добавляем публичный метод для проверки состояния инициализации
    public getIsInitialized(): boolean {
        return this.isInitialized;
    }

    private async initializeApp(): Promise<void> {
        try {
            await this.app.init({
                width: window.innerWidth,
                height: window.innerHeight,
                backgroundColor: this.currentTheme === 'dark' ? 0x1a1a1a : 0xf0f0f0,
                backgroundAlpha: 1,
                antialias: true,
                autoDensity: true,
                resolution: window.devicePixelRatio || 1,
            });

            await new Promise(resolve => setTimeout(resolve, 50));

            if (!this.app.stage) {
                throw new Error('PixiJS stage not initialized');
            }

            this.app.stage.addChild(this.workspaceContainer);
            this.app.stage.addChild(this.uiContainer);

            await this.createNode();
            this.setupEventListeners();
            this.createGrid();

            this.isInitialized = true;

        } catch (error) {
            console.error('Failed to initialize PixiJS application:', error);
            this.createFallbackScene();
            this.isInitialized = true;
        }
    }

    private async createNode(): Promise<void> {
        try {
            this.nodeBase = new PhiNodeBase({
                title: 'Phi Node',
                width: 300,
                height: 200,
                theme: this.currentTheme,
                onRequestEditTitle: () => this.startTitleEditing(),
                onRequestSettings: () => this.openNodeSettings(),
                app: this.app
            });

            // Центрируем нод
            this.nodeBase.node.x = (this.app.screen.width - 300) / 2;
            this.nodeBase.node.y = (this.app.screen.height - 200) / 2;

            // Добавляем ссылку на nodeBase в контейнер для легкого доступа
            (this.nodeBase.node as any).nodeBase = this.nodeBase;

            this.workspaceContainer.addChild(this.nodeBase.node);

        } catch (error) {
            console.error('Failed to create node:', error);
        }
    }

    private setupEventListeners(): void {
        if (!this.app.stage) return;

        this.app.stage.eventMode = 'static';
        this.app.stage.hitArea = this.app.screen;

        // Глобальные обработчики для перетаскивания
        this.app.stage.on('pointermove', (event: PIXI.FederatedPointerEvent) => {
            // Прямой доступ к nodeBase
            if (this.nodeBase && this.nodeBase.getIsDragging()) {
                this.nodeBase.updateDragging(event);
            }
        });

        this.app.stage.on('pointerup', (event: PIXI.FederatedPointerEvent) => {
            if (this.nodeBase) {
                this.nodeBase.stopDragging();
            }
        });

        this.app.stage.on('pointerupoutside', (event: PIXI.FederatedPointerEvent) => {
            if (this.nodeBase) {
                this.nodeBase.stopDragging();
            }
        });

        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.editInput) {
                this.finishTitleEditing(false);
            }
        });
    }

    private createGrid(): void {
        const grid = new PIXI.Graphics();

        if (this.currentGridMode === 'lines') {
            // Линейная сетка
            grid.stroke({ width: 1, color: this.currentTheme === 'dark' ? 0x333333 : 0xcccccc, alpha: 0.5 });

            for (let x = 0; x < this.app.screen.width; x += 20) {
                grid.moveTo(x, 0);
                grid.lineTo(x, this.app.screen.height);
            }

            for (let y = 0; y < this.app.screen.height; y += 20) {
                grid.moveTo(0, y);
                grid.lineTo(this.app.screen.width, y);
            }
        } else if (this.currentGridMode === 'dots') {
            // Точечная сетка
            grid.fill({ color: this.currentTheme === 'dark' ? 0x333333 : 0xcccccc, alpha: 0.3 });

            for (let x = 20; x < this.app.screen.width; x += 20) {
                for (let y = 20; y < this.app.screen.height; y += 20) {
                    grid.circle(x, y, 1);
                }
            }
        }

        this.workspaceContainer.addChildAt(grid, 0);
    }

    private createFallbackScene(): void {
        if (!this.app.stage) return;

        const text = new PIXI.Text('Phi Construct Space\nClick settings icon to edit node title', {
            fontSize: 16,
            fill: 0xffffff,
            align: 'center'
        });
        text.anchor.set(0.5);
        text.x = this.app.screen.width / 2;
        text.y = this.app.screen.height / 2;
        this.app.stage.addChild(text);
    }

    // Добавляем метод открытия настроек:
    private async openNodeSettings(): Promise<void> {
        console.log('🚀 Opening node settings...');

        if (this.settingsPanel) {
            this.settingsPanel.destroy();
            this.settingsPanel = null;
        }

        const nodeData = await this.fetchNodeSettings(this.nodeBase);

        this.settingsPanel = new PhiNodeSettingsPanel(
            this.app,
            this.nodeBase,
            this.currentTheme,
            nodeData,
            (data) => this.saveNodeSettings(data),
            () => this.closeNodeSettings()
        );

        // ЖДЕМ полной инициализации панели!
        await this.settingsPanel.initializationPromise; // ← Добавить await

        // Теперь panelWidth будет правильным!
        const targetX = this.app.screen.width - this.settingsPanel.container.width;

        // Позиционируем и анимируем
        this.settingsPanel.container.x = this.app.screen.width;
        this.uiContainer.addChild(this.settingsPanel.container);
        this.animatePanelAppearance(targetX);

        this.applySettingsEffects();
        console.log('✅ Settings panel opened');
    }

    private animatePanelAppearance(targetX: number): void {
        if (!this.settingsPanel) return;

        const startX = this.app.screen.width; // Начинаем справа
        const duration = 300;
        const startTime = Date.now();

        console.log('🎬 Starting animation:', {
            startX: startX,
            targetX: targetX,
            panelWidth: this.settingsPanel.container.width
        });

        const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);

            const easeProgress = 1 - Math.pow(1 - progress, 3);
            const newX = startX + (targetX - startX) * easeProgress;

            console.log('📊 Animation frame:', {
                progress: progress,
                newX: newX,
                currentX: this.settingsPanel?.container.x
            });

            if (this.settingsPanel) {
                this.settingsPanel.container.x = newX;
            }

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                console.log('✅ Animation completed');
            }
        };

        animate();
    }

    private applySettingsEffects(): void {
        // Сохраняем оригинальные фильтры
        this.originalFilters = this.app.stage.filters || [];

        // Создаем размытие
        this.blurFilter = new PIXI.BlurFilter({ strength: 2 });
        this.app.stage.filters = [...this.originalFilters, this.blurFilter];

        // Блокируем интерактивность
        this.disableInteractivity();
    }

    private async fetchNodeSettings(node: PhiNodeBase): Promise<NodeSettingsData> {
        console.log('📋 Using default settings (backend temporarily disabled)');

        // Временно возвращаем только default настройки
        return {
            title: node.getTitle(),
            componentKey: 'default',
            position: { x: node.node.x, y: node.node.y },
            data: {},
            controls: [
                {
                    type: 'text',
                    key: 'name',
                    label: 'Название нода',
                    defaultValue: node.getTitle()
                },
                {
                    type: 'color',
                    key: 'backgroundColor',
                    label: 'Цвет фона',
                    defaultValue: '#3B82F6'
                },
                {
                    type: 'number',
                    key: 'width',
                    label: 'Ширина',
                    defaultValue: 300,
                    min: 100,
                    max: 800
                },
                {
                    type: 'number',
                    key: 'height',
                    label: 'Высота',
                    defaultValue: 200,
                    min: 50,
                    max: 600
                }
            ]
        };
    }

    // private async fetchNodeSettings(node: PhiNodeBase): Promise<NodeSettingsData> {
    //     try {
    //         const nodeId = typeof node.getNodeId === 'function'
    //             ? node.getNodeId()
    //             : `temp-node-${Date.now()}`;
    //
    //         console.log(`📡 Requesting node data for ID: ${nodeId}`);
    //
    //         // Получаем токен из localStorage или глобальной переменной
    //         const token = localStorage.getItem('authToken') || (window as any).authToken;
    //
    //         const response = await fetch(`/WorkOST/phi_node/${nodeId}`, {
    //             headers: {
    //                 'Authorization': `Bearer ${token}`,
    //                 'Content-Type': 'application/json'
    //             }
    //         });
    //
    //         if (response.ok) {
    //             console.log('✅ Received node data from server');
    //             return await response.json();
    //         } else {
    //             console.warn(`⚠️ Server returned status: ${response.status}`);
    //             throw new Error(`HTTP ${response.status}`);
    //         }
    //     } catch (error) {
    //         console.warn('❌ Failed to fetch node settings:', error);
    //     }
    //
    //     console.log('📝 Using default node settings');
    //     return {
    //         title: node.getTitle(),
    //         componentKey: 'default',
    //         position: { x: node.node.x, y: node.node.y },
    //         data: {},
    //         controls: [
    //             {
    //                 type: 'text',
    //                 key: 'name',
    //                 label: 'Название',
    //                 defaultValue: node.getTitle()
    //             },
    //             {
    //                 type: 'color',
    //                 key: 'color',
    //                 label: 'Цвет',
    //                 defaultValue: '#3B82F6'
    //             }
    //         ]
    //     };
    // }

    private async saveNodeSettings(data: NodeSettingsData): Promise<void> {
        try {
            const token = localStorage.getItem('authToken') || (window as any).authToken;

            const response = await fetch('/WorkOST/phi_node', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error('Failed to save settings');
            }
        } catch (error) {
            console.error('Error saving node settings:', error);
            throw error;
        }
    }

    private closeNodeSettings(): void {
        if (this.settingsPanel) {
            this.settingsPanel.destroy();
            this.settingsPanel = null;
        }

        // Восстанавливаем канвас
        this.app.stage.filters = [...this.originalFilters];
        this.blurFilter = null;
        this.enableInteractivity();
    }

    // ===== РЕДАКТИРОВАНИЕ НАЗВАНИЯ =====

    private startTitleEditing(): void {
        if (!this.nodeBase || this.editInput) return;

        const nodePos = this.nodeBase.getGlobalPosition();
        const headerHeight = 30;
        const inputHeightValue = 24;

        this.createEditInput(nodePos.x, nodePos.y + headerHeight + 5, inputHeightValue);
        this.createEditEffects();
        this.disableInteractivity();
    }

    private createEditInput(x: number, y: number, inputHeight: number): void {
        this.editInput = document.createElement('input');
        this.editInput.type = 'text';
        this.editInput.value = this.nodeBase.getTitle() || 'Phi Node';
        this.editInput.style.position = 'fixed';
        this.editInput.style.left = `${x}px`;
        this.editInput.style.top = `${y}px`;
        this.editInput.style.width = '200px';
        this.editInput.style.height = `${inputHeight}px`;
        this.editInput.style.fontSize = '14px';
        this.editInput.style.fontFamily = 'Arial, sans-serif';
        this.editInput.style.background = 'transparent';
        this.editInput.style.border = 'none';
        this.editInput.style.outline = 'none';
        this.editInput.style.color = '#ffffff';
        this.editInput.style.caretColor = '#ffffff';
        this.editInput.style.opacity = '1';
        this.editInput.style.zIndex = '10000';
        this.editInput.style.padding = '0 8px';
        this.editInput.style.boxSizing = 'border-box';

        this.editInput.onkeydown = (e) => {
            if (e.key === 'Enter') {
                this.finishTitleEditing(true);
            } else if (e.key === 'Escape') {
                this.finishTitleEditing(false);
            }
        };

        this.editInput.onblur = () => {
            this.finishTitleEditing(false);
        };

        document.body.appendChild(this.editInput);
        this.editInput.focus();
        this.editInput.select();
    }

    private createEditEffects(): void {
        // Сохраняем оригинальные фильтры
        this.originalFilters = this.app.stage.filters || [];

        // Создаем размытие (новый синтаксис для v8)
        this.blurFilter = new PIXI.BlurFilter({ strength: 2 });
        this.app.stage.filters = [...this.originalFilters, this.blurFilter];

        // Создаем подложку под input (новый синтаксис для v8)
        this.editOverlay = new PIXI.Graphics();

        const nodePos = this.nodeBase.getGlobalPosition();
        const inputY = nodePos.y + 30 + 5;

        // Красивая подложка
        this.editOverlay.fill({ color: 0x2a2a2a, alpha: 0.9 });
        this.editOverlay.stroke({ width: 2, color: 0x3B82F6, alpha: 0.8 });
        this.editOverlay.roundRect(
            nodePos.x - 5,
            inputY - 5,
            210,
            34,
            6
        );

        this.uiContainer.addChild(this.editOverlay);
    }

    private disableInteractivity(): void {
        this.workspaceContainer.eventMode = 'none';
        this.nodeBase.node.eventMode = 'none';
        this.app.stage.eventMode = 'none';
    }

    private enableInteractivity(): void {
        this.workspaceContainer.eventMode = 'static';
        this.nodeBase.node.eventMode = 'static';
        this.app.stage.eventMode = 'static';
    }

    private finishTitleEditing(save: boolean): void {
        if (this.editInput) {
            if (save && this.editInput.value.trim()) {
                this.nodeBase.setTitle(this.editInput.value.trim());
            }

            document.body.removeChild(this.editInput);
            this.editInput = null;
        }

        // Восстанавливаем фильтры
        this.app.stage.filters = [...this.originalFilters];
        this.blurFilter = null;

        // Убираем подложку
        if (this.editOverlay) {
            this.uiContainer.removeChild(this.editOverlay);
            this.editOverlay.destroy();
            this.editOverlay = null;
        }

        this.enableInteractivity();
    }

    // ===== ПУБЛИЧНЫЕ МЕТОДЫ =====

    public setTheme(theme: ThemeMode): void {
        this.currentTheme = theme;
        this.app.renderer.background.color = theme === 'dark' ? 0x1a1a1a : 0xf0f0f0;

        // Пересоздаем сетку
        this.workspaceContainer.removeChildren();
        this.createGrid();

        // Обновляем нод если он существует
        if (this.nodeBase) {
            this.workspaceContainer.addChild(this.nodeBase.node);
        }

        // TODO: Добавить метод setTheme в PhiNodeBase для обновления темы
    }

    public setGridMode(mode: GridMode): void {
        this.currentGridMode = mode;
        this.workspaceContainer.removeChildren();
        this.createGrid();

        if (this.nodeBase) {
            this.workspaceContainer.addChild(this.nodeBase.node);
        }
    }

    public resize(width: number, height: number): void {
        if (this.app?.renderer) {
            this.app.renderer.resize(width, height);

            if (this.settingsPanel) {
                this.settingsPanel.resize(width, height);
                this.settingsPanel.container.x = width - this.settingsPanel.container.width;
            }

            if (this.app.stage) {
                this.app.stage.hitArea = new PIXI.Rectangle(0, 0, width, height);
            }

            // Пересоздаем сетку
            this.workspaceContainer.removeChildren();
            this.createGrid();

            if (this.nodeBase) {
                this.workspaceContainer.addChild(this.nodeBase.node);
            }

            this.app.renderer.render(this.app.stage);
        }
    }

    public addNode(): void {
        // Будет реализовано позже
        console.log('Add node functionality to be implemented');
    }

    public getTitle(): string {
        return this.nodeBase?.getTitle() || 'Phi Node';
    }

    public async safeDestroy(): Promise<void> {
        try {
            // Завершаем редактирование если активно
            if (this.editInput) {
                this.finishTitleEditing(false);
            }

            if (this.nodeBase) {
                this.nodeBase.destroy();
            }

            if (this.app.stage) {
                this.app.stage.removeChildren();
            }

            if (this.app.renderer) {
                this.app.renderer.destroy();
            }

            this.isInitialized = false;

        } catch (error) {
            console.warn('Error during safe destroy:', error);
        }
    }
}