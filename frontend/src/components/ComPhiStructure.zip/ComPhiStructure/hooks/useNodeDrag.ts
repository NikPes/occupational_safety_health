import { useState, useCallback, useRef } from 'react';
import { PhiNodeData } from '../subcomponents/PhiNode/types/nodeTypes';

interface UseNodeDragProps {
  nodes: PhiNodeData[];
  onNodesUpdate: (nodes: PhiNodeData[]) => void;
  scale: number;
  canvasPosition: { x: number; y: number };
}

interface UseNodeDragReturn {
  draggingNodeId: string | null;
  handleNodeMouseDown: (nodeId: string, event: React.MouseEvent) => void;
}

export const useNodeDrag = ({
  nodes,
  onNodesUpdate,
  scale,
  canvasPosition
}: UseNodeDragProps): UseNodeDragReturn => {
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const dragStartPos = useRef({ x: 0, y: 0 });
  const nodeStartPos = useRef({ x: 0, y: 0 });

  const handleNodeMouseDown = useCallback((nodeId: string, event: React.MouseEvent) => {
    // Проверяем, что кликнули именно на заголовок нода (не на порт или контрол)
    const target = event.target as HTMLElement;
    if (!target.closest('.node-header') && !target.closest('.drag-handle')) {
      return;
    }

    event.stopPropagation();
    event.preventDefault();

    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;

    setDraggingNodeId(nodeId);
    dragStartPos.current = { x: event.clientX, y: event.clientY };
    nodeStartPos.current = { x: node.position.x, y: node.position.y };

    // Меняем курсор
    document.body.style.cursor = 'grabbing';
  }, [nodes]);

  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (!draggingNodeId) return;

    const deltaX = (event.clientX - dragStartPos.current.x) / scale;
    const deltaY = (event.clientY - dragStartPos.current.y) / scale;

    const newX = nodeStartPos.current.x + deltaX;
    const newY = nodeStartPos.current.y + deltaY;

    // Обновляем позицию нода
    onNodesUpdate(
      nodes.map(node =>
        node.id === draggingNodeId
          ? { ...node, position: { x: newX, y: newY } }
          : node
      )
    );
  }, [draggingNodeId, nodes, onNodesUpdate, scale]);

  const handleMouseUp = useCallback(() => {
    if (!draggingNodeId) return;

    setDraggingNodeId(null);
    document.body.style.cursor = '';

    // Убираем обработчики
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  }, [draggingNodeId, handleMouseMove]);

  // Вешаем глобальные обработчики при начале перетаскивания
  useState(() => {
    if (draggingNodeId) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  });

  return {
    draggingNodeId,
    handleNodeMouseDown
  };
};